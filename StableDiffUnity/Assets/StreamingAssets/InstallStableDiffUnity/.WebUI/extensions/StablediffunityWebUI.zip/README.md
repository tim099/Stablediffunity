# This is a stable-diffusion-webui Extensions for Stablediffunity
# 這是Stablediffunity的stable-diffusion-webui插件

Github: https://github.com/tim099/StablediffunityWebUI
Stablediffunity Github: https://github.com/tim099/Stablediffunity


教學文件:https://docs.google.com/presentation/d/1HCK2U4Y_-jIrup5ZG-tYEcpt3p8DBM5SZDnTgOKmBeI/edit?usp=sharing