import os
import sys
import subprocess
from subprocess import PIPE
from pathlib import Path
#batch_path = os.path.expanduser(sys.argv[1])
#with open('RunBatFilePath.txt', 'r') as file:
#    batch_path = file.read()
__location__ = os.path.realpath(
    os.path.join(os.getcwd(), os.path.dirname(__file__)))
batch_path = Path(os.path.join(__location__,'RunBatFilePath.txt')).read_text()
if not os.path.exists(batch_path):
    print("Batch file not found: " + batch_path)
    os.system('PAUSE')
    sys.exit(1)

"""
proc = subprocess.Popen(
    batch_path, shell=True,
    stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
"""
proc = subprocess.Popen(
    batch_path, shell=True)

result = proc.communicate()
print(result)
